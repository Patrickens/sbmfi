function mml_defs = MathMLImport(mml_file, varargin)
% MathML Import-Driver for the MathMLIO Class Library
% (c) Michael Weitzel <mich@el-weitzel.de>,
%     Department of Simulation / University of Siegen
% see http://www.simtec.mb.uni-siegen.de/~weitzel/mathml.php
% for more information.
%
% You will need at least Java 1.5.0 to run this. If the JRE distributed
% with your MatLab ist older than 1.5.0 you need to install JRE 1.5.0
% (use "version -java" to check this; download from http://java.sun.com).
% Remember to set the MATLAB_JAVA environment variable to the path of your
% JRE installation (i.e. do a 'export MATLAB_JAVA=/usr/local/lib/jdk/jre'
% before starting MatLab). If you want to go with J2SE 1.4.x (not
% recommended) you may try the following:
%
% 1. edit toolbox/local/classpath.txt and comment the lines ...
%    $matlabroot/java/jarext/xercesImpl.jar
%    $matlabroot/java/jarext/xml-apis.jar
% 2. get the Xerces DOM-L3 JARs from http://xml.apache.org
% 3. edit MathMLInit.m and uncomment the lines with the javaaddclasspath-
%    directives to use the Xerces DOM L3 implementations
%
% SYNTAX:
%  MathMLImport(<MathML file>);
%  MathMLImport(<MathML file>, [RegExp]);
%  defs = MathMLImport(<MathML file>);
%  defs = MathMLImport(<MathML file>, [RegExp]);
%
% The regular expression is optional and may be used to select named
% MathML declarations from the MathML file. If the return value is omitted
% the MathML declarations are imported as variables directly into the
% caller's workspace. If a return value is specified MathML declarations
% are returned in form of a cell array.
%
% If the MathML file has the suffix ".gz" it is assumed that the MathML
% file is GZIP compressed and opened in a way it can be decompressed on
% the fly.
%
% See also MATHMLEXPORT

if nargin == 0
    warning('MathMLIO:nofile','Dateiname als Parameter fehlt');
    help(mfilename);
    return;
end

% Dieser Eintrag wurde automatisch generiert. Nicht ändern; stattdessen den
% entsprechenden Eintrag in der Datei readCGraph.m.in ändern:
jarfile = [ '/usr' filesep 'share' filesep 'x3cflux' filesep 'java' filesep 'MathMLIO.jar' ];
% In der Entwicklungsumgebung Folgendes einstellen:
%jarfile = fullfile('MathMLIO','dist','MathMLIO.jar');

% Falls MathMLIO.jar noch nicht im classpath liegt, wird es jetzt
% hinzugefuegt. Das passiert hoechstens beim ersten Aufruf von MathMLImport.
% Alle Aufrufe erfolgen im Workspace 'base', da sich Matlab ansonsten
% merkwuerdig verhaelt.
if exist('simtec.flux.xml.mathml.MathMLDomReader','class') ~= 8
    % disp(sprintf('adding ''%s'' to Java classpath...',jarfile));
    assignin('base','mathml_jarfile',jarfile);
    evalin('base','javaaddpath(mathml_jarfile,''-end'')');
    evalin('base','clear mathml_jarfile');
end
evalin('base','import simtec.flux.xml.mathml.*');
evalin('base','import simtec.flux.symbolicmath.*');

% in Anhängigkeit von der Anzahl der Rückgabewerte in den Workspace
% importieren:
import_to_ws = (nargout==0);
% soweit nicht anders spezifiziert, wird alles importiert: '.*'
import_regex = '.*';

% Parameter verarbeiten
if length(varargin)==1 && isa(varargin{1}, 'char')
    import_regex = varargin{1};
end

% einen MathML-DOM-Tree-Reader (Parser) erzeugen
try
    %reader = MathMLDomReaderImplJAXP; % nur J2SE 1.5.0
    reader = MathMLDomReaderImplXercesDOM3; % J2SE 1.4.x & 1.5.0
catch
    rethrow(lasterror);
end

try
    in_stream = java.io.FileInputStream(mml_file);
    % Komprimierte MathML-Dateien per GZIPInputStream dekomprimieren:
    if regexp(mml_file, '\.gz$')
        in_stream = java.util.zip.GZIPInputStream(in_stream);
    end
    in_stream = java.io.BufferedInputStream(in_stream);
    reader.parseFromStream(in_stream);
    clear in_stream;
catch
    rethrow(lasterror);
end

% Referenz auf geparstes MathML-Dokument holen
mml = reader.getMathMLDocument;
clear reader;

% Definitionen über einen regulären Ausdruck auswählen; zurueck kommt eine
% verkettete Liste; diese in ein Cell-Array von MathMLDefinition-Objekten
% konvertieren:
try
    def_list = mml.getDefinitionsByRegExp(import_regex);
catch
    rethrow(lasterror);
end
clear mml;

% Ein Cell-Array für alle Definition erzeugen. Jedes Element ist
% ein Paar (Name,Wert)
if ~import_to_ws
    mml_defs = cell(def_list.size,1);
end;

% MathMLDefinition-Objekte verarbeiten
i=1;
def_iter = def_list.iterator;
while def_iter.hasNext
    def = def_iter.next;
    % Name der Definition
    def_name = char(def.getName);
    % Wert der Definition (Klasse MathMLContentObject)
    def_value = def.getValue;
    
    if def.isEmpty
        % Leere Definitionen werden zu leeren Cells
        def_cell = { def_name, {} };
    elseif def_value.getType == MathMLContentObject.CO_LAMBDA
        % Aus lambda-Ausdrücken werden Function-Handles
        % Referenz auf das MathMLLambdaExpression-Objekt holen
        lambda_obj = def_value;

        % TODO: Was passiert, wenn die Definition keinen Namen hat?
        lambda_name = def_name;
        % Arithmetischer Ausdruck -> String
        lambda_expr = char(lambda_obj.getLambdaExpr.toString);
        % Variablen-Liste -> (Cell-)Array von Strings
        lambda_vars = char(lambda_obj.getVarList.toArray);

        % eine Variablenliste für das Function-Handle erzeugen
        lambda_var_list = lambda_vars(1,:);
        if length(lambda_vars)>1
            for j=2:size(lambda_vars,1)
                lambda_var_list = [ lambda_var_list ',' lambda_vars(j,:) ];
            end
        end
        % Function-Handle in die Variable 'lambda_handle' schreiben:
        eval([ 'lambda_handle =' '@(' lambda_var_list ') ' lambda_expr ';' ]);
        % Ein Paar aus Definitiosname und Anonymous-Function-Handle
        % erzeugen:
        def_cell = { lambda_name, lambda_handle };
    elseif def_value.getType == MathMLContentObject.CO_EXPRESSION
        % Referenz auf das MathMLExpression-Objekt holen
        expr_obj = def_value;
        % TODO: Was passiert, wenn die Expression keinen Namen hat?
        % Unsinnig? Fehlermeldung?
        expr_name = def_name;
        % Arithmetischer Ausdruck -> String
        expr = char(expr_obj.get.toString);
        % Ein Paar aus Definitionsname und Wert erzeugen
        def_cell = { expr_name, expr };
    elseif def_value.getType == MathMLContentObject.CO_VECTOR
        % Referenz auf das MathMLVector-Objekt holen
        vector_obj = def_value;
        % Name des Vektors
        vect_name = def_name;
        % Dimension des Vektors
        dim = vector_obj.getDim;
        % Falls die Matrix symbolische Komponenten hat wird zunächst
        % versucht die symbolischen Komponenten umzuwandeln:
        if vector_obj.isSymbolic
            vector_obj.eval(true);
        end
        % Falls nun immernoch symbolische Komponenten vorhanden sind,
        % wird der Vektor jetzt als Cell-Array importiert:
        if vector_obj.isSymbolic
            warning('MathMLIO:type','vector \"%s\" (def. #%i) has symbolic values and will be imported as cell array',vect_name, i);
            vect = cell(dim,1);
            for j=1:dim
                expr = vector_obj.get(j-1);
                if isa(expr,'ExprTree')
                    if expr.isLiteral
                        vect{j} = expr.getDoubleValue;
                    else
                        vect{j} = char(expr.toString);
                    end
                else
                    vect{j} = 0;
                end
            end
        else
            vect = zeros(dim,1);
            for j=1:dim
                % Double-Werte in den Vektor übernehmen:
                expr = vector_obj.get(j-1);
                if isa(expr,'ExprTree')
                    vect(j) = expr.getDoubleValue;
                else
                    vect(j) = 0;
                end
            end;
        end;
        % ggfs. in einen Spaltenvektor umwandeln:
        if ~(vector_obj.isColumnVector)
            vect = vect';
        end
        % Ein Paar aus Definitionsname und Wert erzeugen
        def_cell = { vect_name, vect };
    elseif def_value.getType == MathMLContentObject.CO_MATRIX
        % Referenz auf das MathMLMatrix-Objekt holen
        matrix_obj = def_value;
        % Name der Matrix
        matrix_name = def_name;
        % Zeilen/Spalten
        rows = matrix_obj.getRows;
        cols = matrix_obj.getCols;
        % Falls die Matrix symbolische Komponenten hat wird zunächst
        % versucht die symbolischen Komponenten umzuwandeln:
        if matrix_obj.isSymbolic
            matrix_obj.eval(true);
        end
        % Falls nun immernoch symbolische Komponenten vorhanden sind,
        % wird die Matrix jetzt als Cell-Array importiert:
        if matrix_obj.isSymbolic
            warning('MathMLIO:type','matrix \"%s\" (def. #%i) has symbolic values and will be imported as cell array', matrix_name, i);
            matrix = cell(rows,cols);
            for u=1:rows
                for v=1:cols
                    expr = matrix_obj.get(u-1,v-1);
                    if isa(expr,'ExprTree')
                        if matrix_obj.get(u-1,v-1).isLiteral
                            matrix{u,v} = matrix_obj.get(u-1,v-1).getDoubleValue;
                        else
                            matrix{u,v} = char(matrix_obj.get(u-1,v-1).toString);
                        end
                    else
                        matrix{u,v} = 0;
                    end
                end
            end
        else
            matrix = zeros(rows,cols);
            for u=1:rows
                for v=1:cols
                    expr = matrix_obj.get(u-1,v-1);
                    if isa(expr,'ExprTree')
                        matrix(u,v) = expr.getDoubleValue;
                    else
                        matrix(u,v) = 0;
                    end
                end
            end
        end
        % ein Paar aus Definitionsname und Wert erzeugen
        def_cell = { matrix_name, matrix };
    end
   
    if import_to_ws
        if isempty(def_cell{1})
            % Wenn die Definition keinen Namen hat, muß ein anonymous-Name
            % erzeugt werden
            anon_i = sprintf('unnamed_MathML_definition_%i', i);
            assignin('caller', anon_i, def_cell{2});
        else
            % Wenn die Definition einen Namen hat, ist alles ok
            assignin('caller', def_cell{1}, def_cell{2});
        end
    else
        % Definition in das Cell-Array eintragen
        mml_defs{i} = def_cell;
    end
    i = i+1;
end

% Java-Paket-Import löschen
evalin('base','clear import');

end % function MathMLImport
