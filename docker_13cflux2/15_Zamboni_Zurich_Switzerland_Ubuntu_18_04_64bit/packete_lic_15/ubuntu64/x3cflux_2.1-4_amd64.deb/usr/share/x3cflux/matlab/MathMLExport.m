function MathMLExport(mml_file, mml_type, varargin)
% MathML Export Driver for the MathMLIO Class Library
% (c) Michael Weitzel <mich@el-weitzel.de>
%     Department of Simulation / University of Siegen
% see http://www.simtec.mb.uni-siegen.de/~weitzel/mathml.php
% for more information.
%
% This script can export MatLab matrices, vectors or scalars into
% MathML files.
%
% SYNTAX:
%  MathMLExport(<MathML file>, <MathML type>, v1, v2 ...)
%
% If the file name has the suffix ".gz" it is assumed that data should
% be written to a GZIP compressed MathML file.
% <MathML type> specifies the type of MathML that is generated:
%    'c'    -> Content-MathML
%    'p'    -> Presentation-MathML
%    'cp'   -> Content-MathML mit eingebettetem Presentation-MathML
%    'pc'   -> Presentation-MathML mit eingebettetem Content-MathML
%
% See also MATHMLIMPORT

if nargin == 0
    help(mfilename);
    return;
end

if nargin == 0
    warning('MathMLIO:nofile','Dateiname als Parameter fehlt');
    help(mfilename);
    return;
end

% Dieser Eintrag wurde automatisch generiert. Nicht ändern; stattdessen den
% entsprechenden Eintrag in der Datei MathMLIOExport.m.in ändern:
jarfile = [ '/usr' filesep 'share' filesep 'x3cflux' filesep 'java' filesep 'MathMLIO.jar' ];
% In der Entwicklungsumgebung Folgendes einstellen:
%jarfile = fullfile('MathMLIO','dist','MathMLIO.jar');

% Falls MathMLIO.jar noch nicht im classpath liegt, wird es jetzt
% hinzugefuegt. Das passiert hoechstens beim ersten Aufruf von MathMLExport.
% Alle Aufrufe erfolgen im Workspace 'base', da sich Matlab ansonsten
% merkwuerdig verhaelt.
if exist('simtec.flux.xml.mathml.MathMLDomWriter','class') ~= 8
    % disp(sprintf('adding ''%s'' to Java classpath...',jarfile));
    assignin('base','mathml_jarfile',jarfile);
    evalin('base','javaaddpath(mathml_jarfile,''-end'')');
    evalin('base','clear mathml_jarfile');
end
evalin('base','import simtec.flux.xml.mathml.*');
evalin('base','import simtec.flux.symbolicmath.*');

% erzeuge ein neues MathML-Dokument
try
    mml = MathMLDocument;
catch
    rethrow(lasterror);
end

if strcmp(mml_type, 'c')
    mml_type = MathMLDocument.MML_CONTENT;
elseif strcmp(mml_type, 'p')
    mml_type = MathMLDocument.MML_PRESENTATION;
elseif strcmp(mml_type, 'cp')
    mml_type = MathMLDocument.MML_CONTENT_WITH_PRESENTATION;
elseif strcmp(mml_type, 'pc')
    mml_type = MathMLDocument.MML_PRESENTATION_WITH_CONTENT;
else
    error('unsupported MathML-Type: \"%s\"', mml_type);
end

% ein Zähler
exported = 0;

for k=1:length(varargin)
    def_name = varargin{k};
    try
        def_value = evalin('caller', def_name);
    catch
	warning('MathMLIO:undef','argument \"%s\" is undefined', def_name);
        continue;
    end
    
    if ~(isa(def_value, 'double') || isa(def_value, 'logical'))
        warning('MathMLIO:type','not exporting "%s": wrong type', def_name);
        continue;
    end
    
    % Export der Matrix / des Vektors / des Wertes
    [rows,cols] = size(def_value);
    
    if rows==1 && cols==1
        % ein Wert
        expr = ExprTree(def_value);
        mml_content = mml.createExpression(expr);
    elseif rows==1
        % ein liegender Vektor (row-vector)
        mml_content = mml.createVector(cols);
        mml_content.setRowVector;
        mml_content.copyFrom(def_value);
    elseif cols==1
        % ein stehender Vektor (column-vector)
        mml_content = mml.createVector(rows);
        mml_content.setColumnVector;
        mml_content.copyFrom(def_value);
    else
        % eine allgemeine Matrix
        mml_content = mml.createMatrix(rows,cols);
        mml_content.copyFrom(def_value);
    end
    
    % Definition anlegen
    mml.createDeclare(mml_content,def_name);
    exported = exported + 1;
end

if exported > 0
    try
        writer = MathMLDomWriterImplXercesDOM3;
        mml.serializeToDom(writer, mml_type);
        out_stream = java.io.FileOutputStream(mml_file);
        % Auf Wunsch Kompression einschalten:
        if regexp(mml_file, '\.gz$')
            out_stream = java.util.zip.GZIPOutputStream(out_stream);
        end
        out_stream = java.io.BufferedOutputStream(out_stream);
        writer.writeToStream(out_stream);
        out_stream.close;
    catch
        % Objekte zerstören
        clear writer; clear mml; clear java;
        % Java-Paket-Import löschen
        evalin('base','clear import');
        % Fehlermeldung
	rethrow(lasterror);
    end
else
    % Objekte zerstören
    clear mml; clear java;
    % Java-Paket-Import löschen
    evalin('base','clear import');
    % Fehlermeldung
    error('FAILED to write the MathML file: refusing to create an empty file');
end

% Java-Paket-Import löschen
evalin('base','clear import');

