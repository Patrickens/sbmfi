function drawCovariance(hdf5f)
% drawCovariance(hdf5f), (c) Michael Weitzel 2010
%
% Visualisiert eine von fwdsim exportierte Kovarianzmatrix.
% Der Parameter hdf5f gibt den Dateinamen der HDF5-Datei an.
%
if exist('OCTAVE_VERSION','builtin') == 5
    error('sorry, this script does not work under Octave :-(');
end

if ~exist(hdf5f,'file')
    error('file \"%s\" does not exist', hdf5f);
end

try
    A = hdf5read(hdf5f,'/cov/matrix');
    rlh = hdf5read(hdf5f,'/cov/r');
    clh = hdf5read(hdf5f,'/cov/c');
catch err
    error(['Error reading covariance matrix (%s). ', ...
        'Tell fwdsim to comput it?!'], err.message);
end

% default-Gamma-Faktor
gamma = 1;

rl = cell(size(A,1));
for k=1:size(A,1)
    rl{k} = rlh(k).Data(1:end-2);
end
cl = cell(size(A,2));
for k=1:size(A,2)
    cl{k} = clh(k).Data(1:end-2);
end

rl = { rl(1:2:length(rl)), rl(2:2:length(rl)) };
cl = { cl(1:2:length(cl)), cl(2:2:length(cl)) };
A = { A(1:2:size(A,1),1:2:size(A,2)), A(2:2:size(A,1),2:2:size(A,2)) };
titles = { 'Net Fluxes', 'Exchange Fluxes'};

figure('Position',[1 1 800 275]);
clf;
orient 'landscape';
hold on;
for k=1:2
    Ak = A{k};
    rlk = rl{k};
    clk = cl{k};
    
    % 'Clustern'
    P = symrcm(Ak);
    Ak = Ak(P,P);
    rlk = rlk(P);
    clk = clk(P);
    
    % Originalwerte sichern
    Ako = Ak;   
    
    % Erkennen/Deckeln von Ausreißern
    Q = [min(Ak(:)) max(Ak(:))]; %quantile(Ak(:),[0.02,0.98]);
    mi = Q(1);
    ma = Q(2);
    Ak(Ak < mi) = mi;
    Ak(Ak > ma) = ma;
    
    % Farbpalette
    P = jet(256); % gray(256);
    colormap(P);
    
    % Gamma-Korrektur
    [s,t] = affxf([mi,ma],[0,1]);
    Ak = s*Ak+t;
    Ak = Ak.^gamma;
    % Transformieren
    [s,t] = affxf([0,1],[1,size(P,1)]);
    Ak = s*Ak+t;
    
    subplot(1,2,k);
    xlim([-.1,1.1]);
    ylim([-.1,1.1]);
    grid('off'); axis('off'); % Gitter und Achsen abschalten
    rows = size(Ak,1);
    cols = size(Ak,2);
    wx = 1/cols;
    wy = 1/rows;
    X = wx * [0 1 1 0];
    Y = wy * [0 0 1 1];
    
    for i=1:rows
        for j=1:cols
            if abs(Ako(rows-i+1,j))<eps
                c = [1 1 1];
                patch((j-1)*wx+X(1:3),(i-1)*wy+Y(1:3),c,'EdgeColor','k');
                c = [0 0 0];
                patch((j-1)*wx+[X(1) X(3:4)],(i-1)*wy+[Y(1) Y(3:4)],c,'EdgeColor','k');
            else
                c = P(round(Ak(rows-i+1,j)),:);
                patch((j-1)*wx+X,(i-1)*wy+Y,c,'EdgeColor','k');
            end
            
        end
    end
    
    for i=1:rows
        text(-0.01,wy/4+(i-1)*wy,rlk{rows-i+1},'HorizontalAlignment','right');
    end
    for j=1:cols
        text(wx/2+(j-1)*wx,0.01+rows*wy,clk{j},'Rotation',90);
    end
    text(0.5,-0.1,titles{k},'HorizontalAlignment','center');
    colorbar;
    caxis([mi,ma]);
end
hold off;

function [s,t]=affxf(x,u)
% x1->u1, x2->u2
s = (u(1)-u(2))/(x(1)-x(2));
t = (x(1)*u(2)-x(2)*u(1))/(x(1)-x(2));
